import Table from 'react-bootstrap/Table';
import axios from 'axios';
import { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import { DtPicker } from 'react-calendar-datetime-picker'
import 'react-calendar-datetime-picker/dist/style.css'

export const PatientHome = () => {
    if (localStorage.getItem("type") !== "Patient") {
        window.location.href = "/";
        localStorage.setItem("doctorSlotId",0);
    }
    var [slots, setSlots] = useState([]);
    var [doctors, setDoctors] = useState([]);
    var[doctorSlots,setDoctorSlots]=useState([]);

    useEffect(() => {
        const fetchData = async () => {
            var result = await axios.get("http://localhost:8080/GetAllPatientSlots/" + localStorage.getItem("email"))
                .then((res) => {
                    setSlots(res.data);
                })
                .catch((err) => {
                    console.log(err);
                });
            var result2 = await axios.get("http://localhost:8080/GetAllDoctors")
                .then((res) => {
                    setDoctors(res.data);
                    console.log(res.data);
                })
                .catch((err) => {
                    console.log(err);
                });
        };
        fetchData();
    },[]);
    const getDoctorSlots = async (doctorId) => {
        var result = await axios.get("http://localhost:8080/GetAllAvailableSlots/" + doctorId)
            .then((res) => {
                setDoctorSlots(res.data);
            })
            .catch((err) => {
                console.log(err);
            }
            );
            console.log(doctorSlots);
    };

    const makeAppointment = async () => {
        var slotId =parseInt(localStorage.getItem("doctorSlotId"));
        var slot={
            id:slotId,
            patientId:localStorage.getItem("email"),
            patientName:localStorage.getItem("name"),
                }
        console.log(slot);
        var header = {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        };

        axios.post("http://localhost:8080/PatientReserveSlot",slot,header)
        .then((res)=>{
            if(res.status===200){
                alert("Appointment Booked Successfully");
                window.location.href="/patientHome";
            }
        })
        .catch((err)=>{
            console.log(err);
        })

    };

    const cancelSlot = async (slotId) => {
        var result = await axios.delete(`http://localhost:8080/PatientCancelSlot/${slotId}`)
            .then((res) => {
                if (res.status === 200) {
                    alert("Appointment Cancelled Successfully");
                    window.location.href = "/patientHome";
                }
            })
            .catch((err) => {
                if (err.response.status === 403) {
                }
            });
    };
    const editSlot=(slotId)=>{
        localStorage.setItem("SlotId",slotId);
        window.location.href="/editAppointment";
    }


  return (
    <>
    <br/>
    <div>
        <h3>My Slots</h3>
        <br/>
    <Table striped bordered hover>
      <thead>
        <tr>
        <th colspan="3">Appointment</th>

        </tr>
        <tr>
          <th>ID</th>
          <th>Date</th>
          <th>Hour</th>
          <th>Doctor</th>
          <th>Edit</th>
          <th>Cancel</th>
        </tr>
      </thead>
      <tbody>
        {
            slots && slots.map((slot) => {
                return (
                    <tr
                    key={slot.id}
                    >
                        <td>{slot.id}</td>
                        <td>{slot.date}</td>
                        <td>{slot.time}</td>
                        <td>{slot.doctorName}</td>
                        <td><Button variant="primary" onClick={() => {
                           editSlot(slot.id);
                        }}>Edit</Button></td>
                        <td><Button variant="danger" onClick={() => {
                            cancelSlot(slot.id);
                        }}>Cancel</Button></td>
                    </tr>
                );
            })

        }
      </tbody>
    </Table>
    <br/>

    <div style={
        {
            width:"50%",
            height:"50%",
            marginLeft:"25%",
        }
    }>
        <br/>
        <br/>

    
    
    </div>
    <div
     style={
        {
            "width":"50%",
            "height":"50%",
            "marginLeft":"25%",
            "border":"1px solid black",
            "borderRadius":"10px",
            "padding":"20px",

        }
     }
    >
    <h3>Make Appointment </h3>
    <br/>
    <label 
    >Choose a doctor: </label>
    <select name="doctor" id="doctor"
    onChange={(e)=>{
        getDoctorSlots(e.target.value);
    }}
    style={
        {
            
            "marginLeft":"20px",
        }
    }

    >
        <option value="0">Select Doctor</option>
        {
            doctors && doctors.map((doctor) => {
                return (
                    <option
                    style={
                        {
                            "width":"100px",
                            "height":"20px",
                            "marginLeft":"25%",
                        }
                    }
                    key={doctor.email} 
                    value={doctor.email}

                    >Dr. {doctor.fullName}</option>
                );
            })

        }
    </select>
    <br/>
    <br/>
    <label >Choose a slot:</label>
    <select name="doctorSlot" id="doctorSlot"
    onChange={(e)=>{
        localStorage.setItem("doctorSlotId",e.target.value);
    }}
    style={
        {
            
            "marginLeft":"37px",
        }
    }
    >
        <option value="0">Select Slot</option>
        {
            doctorSlots && doctorSlots.map((doctorSlot) => {
                return (
                    <option
                    key={doctorSlot.id} 
                    value={doctorSlot.id}
                    >{doctorSlot.date} - {doctorSlot.time}
                    </option>
                );
            })
        }
    </select>
    <br/>
    <br/>
    <Button variant="primary" onClick={() => {
                        makeAppointment();
                    }}>Make Appointment</Button>
    </div>
    </div>
    </>
  );
}

