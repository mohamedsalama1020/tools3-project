import logo from './logo.svg';
import './App.css';
import { Route } from 'react-router-dom';
import { BrowserRouter, Routes } from 'react-router-dom';
import { SignIn } from './Components/SignIn/SignIn';
import { SignUp } from './Components/SignUp/SignUp';
import {NavBar} from './Components/NavBar/NavBar';
import { DoctorHome } from './Components/DoctorHome/DoctorHome';
import { EditSlot } from './Components/EditSlot/EditSlot';
import { PatientHome } from './Components/PatientHome/PatientHome';
import { EditAppointment } from './Components/EditAppointment/EditAppointment';
function App() {
  return (
    <div className="">
      <BrowserRouter>
        <NavBar/>
        <Routes>
          <Route path="/" element={<SignIn />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/doctorHome" element={<DoctorHome />} />
          <Route path="/editSlot" element={<EditSlot />} />
          <Route path="/patientHome" element={<PatientHome />} />
          <Route path="/editAppointment" element={<EditAppointment />} />
        </Routes>
      </BrowserRouter>

      </div>
  );
}

export default App;
