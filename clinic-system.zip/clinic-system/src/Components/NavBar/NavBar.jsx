import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Button from 'react-bootstrap/Button';
export const  NavBar=()=> {
    if(localStorage.getItem("type")==="Doctor"){
        
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="/doctorHome">Hello Dr.{localStorage.getItem("name")} </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" bg="dark"/>
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="/doctorHome">Home</Nav.Link>
            <NavDropdown title="Dropdown" id="basic-nav-dropdown">
              <NavDropdown.Item onClick={
                     () => {
                      localStorage.clear();
                      window.location.href="/";
                    }
                  }>Sign Out</NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
    }
    else if(localStorage.getItem("type")==="Patient"){
        return (
            <Navbar expand="lg" className="bg-body-tertiary">
              <Container>
                <Navbar.Brand href="/patientHome">Hello {localStorage.getItem("name")} - Patient</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                  <Nav className="me-auto">
                    <Nav.Link href="/patientHome">Home</Nav.Link>
                    <NavDropdown title="Dropdown" id="basic-nav-dropdown">
                    <NavDropdown.Item onClick={
                     () => {
                      localStorage.clear();
                      window.location.href="/";
                    }
                  }>Sign Out</NavDropdown.Item>
                    </NavDropdown>
                  </Nav>
                </Navbar.Collapse>
              </Container>
            </Navbar>
          );
    }
    else{
        return(<></>);
    }
}

