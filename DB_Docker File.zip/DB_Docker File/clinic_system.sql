CREATE TABLE user (
    email VARCHAR(255) PRIMARY KEY,
    password VARCHAR(255),
    type VARCHAR(255),
    fullName VARCHAR(255)
);

CREATE TABLE slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date VARCHAR(255),
    hour VARCHAR(255),
    doctor_id VARCHAR(255),
    doctor_Name VARCHAR(255),
    status VARCHAR(255),
    patient_Name VARCHAR(255),
    patient_id VARCHAR(255)
);