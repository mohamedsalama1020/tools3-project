import React, { useEffect, useState } from "react";
import axios from "axios";
import Button from 'react-bootstrap/Button';

export const EditAppointment = () => {
    if (localStorage.getItem("type") !== "Patient") {
        window.location.href = "/";
    }
    var [doctorSlots,setDoctorSlots]=useState([]);
    var [doctors, setDoctors] = useState([]);
    var [newSlotId,setNewSlotId]=useState();

    useEffect(() => {
        const fetchData = async () => {
            var result2 = await axios.get("http://172.17.215.189:8080/GetAllDoctors")
                .then((res) => {
                    setDoctors(res.data);
                    console.log(res.data);
                })
                .catch((err) => {
                    console.log(err);
                });
        };
        fetchData();
    },[]);
    const getDoctorSlots = async (doctorId) => {
        var result = await axios.get("http://172.17.215.189:8080/GetAllAvailableSlots/" + doctorId)
            .then((res) => {
                setDoctorSlots(res.data);
            })
            .catch((err) => {
                console.log(err);
            }
            );
            console.log(doctorSlots);
    }
    const makeAppointment = async () => {
                var header = {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        };

        axios.put("http://localhost:8080/UpdateSlotStatus/"+localStorage.getItem("SlotId")+"/"+newSlotId,header)
        .then((res)=>{
            if(res.status===200){
                alert("Appointment Booked Successfully");
                window.location.href="/patientHome";
            }
        })
        .catch((err)=>{
            if(err.response.status===403){
                alert("Slot Already Booked");
            }
        })
    }
    return (
        <>
        <br/>
        <br/>
        <br/>
        <div className="container"

        style={
            {
                "width":"50%",
                "height":"50%",
                "marginLeft":"25%",
                "border":"1px solid black",
                "borderRadius":"10px",
                "padding":"20px",
    
            }
        }
        >
        <h3>Edit Appointment with ID: {localStorage.getItem("SlotId")} </h3>
        <br/>
        <label 
        >Choose a doctor: </label>
        <select name="doctor" id="doctor"
        onChange={(e)=>{
            getDoctorSlots(e.target.value);
        }}
        style={
            {
                
                "marginLeft":"20px",
            }
        }
    
        >
            <option value="0">Select Doctor</option>
            {
                doctors && doctors.map((doctor) => {
                    return (
                        <option
                        style={
                            {
                                "width":"100px",
                                "height":"20px",
                                "marginLeft":"25%",
                            }
                        }
                        key={doctor.email} 
                        value={doctor.email}
    
                        >Dr. {doctor.fullName}</option>
                    );
                })
    
            }
        </select>
        <br/>
        <br/>
        <label >Choose a slot:</label>
        <select name="doctorSlot" id="doctorSlot"
        onChange={(e)=>{
            setNewSlotId(e.target.value);
        }}
        style={
            {
                
                "marginLeft":"37px",
            }
        }
        >
            <option value="0">Select Slot</option>
            {
                doctorSlots && doctorSlots.map((doctorSlot) => {
                    return (
                        <option
                        key={doctorSlot.id} 
                        value={doctorSlot.id}
                        >{doctorSlot.date} - {doctorSlot.time}
                        </option>
                    );
                })
            }
        </select>
        <br/>
        <br/>
        <Button variant="primary" onClick={() => {
                            makeAppointment();
                        }}>Make Appointment</Button>
        </div>
        </>
      );
}