import Table from 'react-bootstrap/Table';
import axios from 'axios';
import { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import { DtPicker } from 'react-calendar-datetime-picker'
import 'react-calendar-datetime-picker/dist/style.css'

export const DoctorHome = () => {
    if (localStorage.getItem("type") !== "Doctor") {
        window.location.href = "/";
    }
    var [date, setDate] = useState();
    var [slots, setSlots] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            var result = await axios.get("http://localhost:8080/GetAllDoctorSlots/" + localStorage.getItem("email"))
                .then((res) => {
                    setSlots(res.data);
                })
                .catch((err) => {
                    console.log(err);
                });
        };
        fetchData();
        console.log(slots);
    },[]);

    const addSlot = async () => {
        if(date){
        if(date.hour<10){
            date.hour="0"+date.hour;
        }
        if(date.minute<10){
            date.minute="0"+date.minute;
        }
        if(date.day<10){
            date.day="0"+date.day;
        }
        if(date.month<10){
            date.month="0"+date.month;
        }
        var slotDate=date.day + "/"+date.month+"/"+date.year;
        console.log(slotDate);
        
        var slotTime=date.hour+":"+date.minute;
        var slot = {
            doctorId: localStorage.getItem("email"),
            date: slotDate,
            time: slotTime,
            doctorName: localStorage.getItem("name"),

        };
        console.log(slot);

        var result = await axios.post("http://localhost:8080/CreateNewSlot", slot)
            .then((res) => {
                if (res.status === 200) {
                    alert("Slot Added Successfully");
                    window.location.href = "/doctorHome";
                }
            })
            .catch((err) => {
                if (err.response.status === 403) {
                    alert("Slot Already Exists");
                }
            });
    }
    else{
        alert("Please select a date and time");
        return;
    }

    };

    const cancelSlot = async (slotId) => {
        var result = await axios.delete(`http://localhost:8080/DoctorDeleteSlot/${slotId}`)
            .then((res) => {
                if (res.status === 200) {
                    alert("Slot Cancelled Successfully");
                    window.location.href = "/doctorHome";
                }
            })
            .catch((err) => {
                if (err.response.status === 403) {
                }
            });
    };
    const editSlot=(slotId)=>{
        localStorage.setItem("slotId",slotId);
        window.location.href="/editSlot";
    }


  return (
    <div>
        <h3>My Slots</h3>
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>Slot ID</th>
          <th>Date</th>
          <th>Hour</th>
          <th>status</th>
          <th>Edit</th>
          <th>Cancel</th>
        </tr>
      </thead>
      <tbody>
        {
            slots && slots.map((slot) => {
                return (
                    <tr>
                        <td>{slot.id}</td>
                        <td>{slot.date}</td>
                        <td>{slot.time}</td>
                        <td>{slot.status}</td>
                        <td><Button variant="primary" onClick={() => {
                           editSlot(slot.id);
                        }}>Edit</Button></td>
                        <td><Button variant="danger" onClick={() => {
                            cancelSlot(slot.id);
                        }}>Cancel</Button></td>
                    </tr>
                );
            })

        }
      </tbody>
    </Table>
    <br/>

    <div style={
        {
            width:"50%",
            height:"50%",
            marginLeft:"25%",
        }
    }>
        <br/>
        <br/>
    <h3>Add New Slot</h3>
    <DtPicker
            withTime={true}
            dateFormat="DD/MM/YYYY"
            onChange={date => setDate(date)}
            value={date}
            showTimeInput={true}
            placeholder= "Select Date and Time"


        />
        <br/>
        <Button variant="primary" onClick={() => {
            addSlot();
        }}>Add Slot</Button>
    </div>


    </div>
  );
}

