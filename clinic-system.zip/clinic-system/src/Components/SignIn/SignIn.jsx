import React from 'react';
import {
  MDBBtn,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBInput,
  MDBIcon
}from 'mdb-react-ui-kit';

import { useState } from 'react';
import "./SignIn.css";
import axios from "axios";

export const SignIn = () => {
    if(localStorage.getItem("email")){
        if(localStorage.getItem("type")==="Doctor"){
            window.location.href="/doctorHome";
        }
        else if(localStorage.getItem("type")==="Patient"){
            window.location.href="/patientHome";
        }
    }

   
    var [email, setEmail] = useState("");
    var [password, setPassword] = useState("");
    var [isValid, setIsValid] = useState(true);

    const logIn = async () => {
        if(email==="" || password===""){
            alert("Please fill all the fields");
            return;
        }
        var user={
            email:email,
            password:password,
        }
        var headers = {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
                        
          }
        
        var result = await axios.post("http://localhost:8080/SignIn",user,headers)
        .then((res) => {
        if(res.status===200){
            console.log(res.status);
            localStorage.setItem("email",res.data.email);
            localStorage.setItem("type",res.data.type);
            localStorage.setItem("name",res.data.fullName);
            if(res.data.type==="Doctor"){
                window.location.href="/doctorHome"; 
            }
            else if(res.data.type==="Patient"){
                window.location.href="/patientHome";
            }
        }
        }).catch((err) => {
            if(err.response.status===403){
                setIsValid(false);
            }
        }
        );

    };


    return (
        <MDBContainer fluid>

        <MDBRow className='d-flex justify-content-center align-items-center h-100'>
          <MDBCol col='12'>
  
            <MDBCard className='bg-dark text-white my-5 mx-auto' style={{borderRadius: '1rem', maxWidth: '400px'}}>
              <MDBCardBody className='p-5 d-flex flex-column align-items-center mx-auto w-100'>
  
                <h2 className="fw-bold mb-2 text-uppercase">Login</h2>
                <p className="text-white-50 mb-5">Please enter your login and password!</p>
  
                <MDBInput wrapperClass='mb-4 mx-5 w-100' labelClass='text-white' label='Email address' id='formControlLg' type='email' size="lg"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
                style={{
                    "color":"white"
                }}

                />
                <MDBInput wrapperClass='mb-4 mx-5 w-100' labelClass='text-white' label='Password' 
                id='formControlLg' type='password' size="lg"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                style={{
                    "color":"white"
                }}
                />
  
                <MDBBtn outline className='mx-2 px-5' color='white' size='lg'
                onClick={() => {
                    logIn();
                    }}                
                >
                  Login
                </MDBBtn>
                <br/>
                {isValid ? null : (
                    <p className="text-danger">Invalid Credentials</p>
                )
                }
                <br/>
                <div>
                  <p className="mb-0">Don't have an account? <a href="/signup" class="text-white-50 fw-bold">Sign Up</a></p>
  
                </div>
              </MDBCardBody>
            </MDBCard>
  
          </MDBCol>
        </MDBRow>
  
      </MDBContainer>
    );
}