import React, { useState } from "react";
import axios from "axios";
import Button from 'react-bootstrap/Button';
import { DtPicker } from 'react-calendar-datetime-picker'
import 'react-calendar-datetime-picker/dist/style.css'

export const EditSlot = () => {

    if (localStorage.getItem("type") !== "Doctor") {
        window.location.href = "/";
    }
    var [date, setDate] = useState();
    var slotId = localStorage.getItem("slotId");

    const updateSlot = async () => {
        if(date){
        if(date.hour<10 ){
            date.hour="0"+date.hour;
        }
        if(date.minute<10 ){
            date.minute="0"+date.minute;
        }
        if(date.day<10){
            date.day="0"+date.day;
        }
        if(date.month<10){
            date.month="0"+date.month;
        }
        var slotDate=date.day + "/"+date.month+"/"+date.year;
        console.log(slotDate);
        
        var slotTime=date.hour+":"+date.minute;
        var slot = {
            slotId:slotId,
            date: slotDate,
            time: slotTime,
            doctorId: localStorage.getItem("email"),
        };
        console.log(slot);

        var result = await axios.post(`http://localhost:8080/DoctorUpdateSlot/${slotId}`, slot)
            .then((res) => {
                if (res.status === 200) {
                    alert("Slot Updated Successfully");
                    window.location.href = "/doctorHome";
                }
            })
            .catch((err) => {
                if (err.response.status === 403) {
                    alert("Slot Already Exists");
                }
            });
        }
        else{
            alert("Please fill all the fields");
        }
    }
    return(
        <div className="container"
        style={
            {
                "margin-top": "100px",
                "margin-left": "300px",
                "margin-right": "300px",
                "border": "1px solid black",
                "boxSizing": "border-box",
                "width": "50%",
                "padding": "20px",
                "borderRadius": "10px",
                "backgroundColor": "white",
                "boxShadow": "0 0 10px 0 black"
            }
        }
        >
            <br/>
            
            <h3>
                Edit Slot wiht Slot ID :{slotId}
            </h3>
            <br/>
            <br/>
                <div className="col-6">
                    <DtPicker
                        value={date}
                        onChange={setDate}
                        className="form-control"
                        placeholder="Select Date and Time"
                        showTimeInput={true}
                        withTime={true}
                    />
                </div>
                <br/>
                <br/>
                <Button
                    className="btn btn-primary"
                    onClick={updateSlot}
                >
                    Update
                </Button>



        </div>
    )
}

